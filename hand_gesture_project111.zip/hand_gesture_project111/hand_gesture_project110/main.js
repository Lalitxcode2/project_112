
var think_1 = "";
var think_2 = "";

Webcam.set({
    width:350,
    height:300,
    image_format : 'png',
    png_quality:90
});

webcam = document.getElementById("webcam");

Webcam.attach('#webcam');

function snapshot(){
    Webcam.snap(function(selfie) {
        document.getElementById("snap").innerHTML = '<img id="captured_img" src="'+selfie+'">';
    });
}

console.log('ml5 version:',ml5.version);

classifier = ml5.imageClassifier('https://teachablemachine.withgoogle.com/models/z3uwqgCf6/model.json',model_loaded);

function model_loaded(){
    console.log('Model Loaded'); 
}

function speak1(){
    var synth = window.speechSynthesis;
    var data1 = "Prediction 1 is " + think_1;
    var data2 = "Prediction 2 is " + think_2;
    var voice = new SpeechSynthesisUtterance(data1+data2);
    synth.speak(voice);
}

function check_prediction(){
    img = document.getElementById('captured_img');
    classifier.classify(img,gotResult);
}

function gotResult(error,results){
    if(error){
        console.error(error); 
    }
    else{
        console.log(results);
        think_1 = results[0].label;
        think_2 = results[1].label;
        document.getElementById("emotion1").innerHTML = results[0].label;
        document.getElementById("emotion2").innerHTML = results[1].label;
        speak1();

        if(prediction_1 == "thumbs up"){
            document.getElementById("emoji1").innerHTML = "&#128077;";  
        }

        if(prediction_1 == "thumbs down"){
            document.getElementById("emoji1").innerHTML = "&#128078;";  
        }

        if(prediction_1 == "hi or bye"){
            document.getElementById("emoji1").innerHTML = "&#128400;";  
        }

        if(prediction_1 == "amazing"){
            document.getElementById("emoji1").innerHTML = "&#128076;";  
        }

        if(prediction_1 == "victory"){
            document.getElementById("emoji1").innerHTML = "&#9996;";  
        }


        if(prediction_2 == "thumbs up"){
            document.getElementById("emoji2").innerHTML = "&#128077;";  
        }

        if(prediction_2 == "thumbs down"){
            document.getElementById("emoji2").innerHTML = "&#128078;";  
        }

        if(prediction_2 == "hi or bye"){
            document.getElementById("emoji2").innerHTML = "&#128400;";  
        }

        if(prediction_2 == "amazing"){
            document.getElementById("emoji2").innerHTML = "&#128076;";  
        }

        if(prediction_2 == "victory"){
            document.getElementById("emoji2").innerHTML = "&#9996;";  
        }

    }
}